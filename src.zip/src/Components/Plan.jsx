import React from 'react'


const Plan = () => {
  return (
    <div className='PlanBLock'>
        <h1> Plan your trip with travel expert </h1>
        <p>Our professional advisors can craft your perfect itinerary</p>
    </div>
  )
}

export default Plan